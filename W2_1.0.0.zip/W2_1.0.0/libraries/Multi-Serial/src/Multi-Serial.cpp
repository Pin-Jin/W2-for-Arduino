/*****************
Dummy library so examples might be added to examples menu tree
******************/